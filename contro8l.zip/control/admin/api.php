<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

// ... (دوال التشفير وفك التشفير كما هي) ...
function decrypt_data($data, $config) {
    $encrypted_data = base64_decode($data);
    $key = hash('sha256', $config['encryption_key'], true);
    $decrypted = openssl_decrypt($encrypted_data, 'AES-256-ECB', $key, OPENSSL_RAW_DATA);
    return $decrypted ?: '';
}

function get_txt_data($file, $config){
    if(!file_exists($file)) return [];
    $encrypted_data = file_get_contents($file);
    $decrypted_data = decrypt_data($encrypted_data, $config);
    $data = json_decode($decrypted_data, true) ?: [];
    
    // *** الإصلاح هنا: تأكد من أن البيانات دائمًا مصفوفة مفهرسة قبل إرسالها ***
    if (is_array($data)) {
        return array_values($data);
    }
    return $data;
}

$config = [
    'encryption_key' => 'AmeerMatchNow$@&zz2024SecureKey!!'
];

$type = $_GET['type'] ?? 'packages';
$data_folder = __DIR__ . '/../data';

$data = []; // قيمة افتراضية

switch ($type) {
    case 'packages':
        $packages_file = $data_folder . '/packages.txt';
        $data = get_txt_data($packages_file, $config);
        break;
        
    case 'channels':
        if (isset($_GET['package_id'])) {
            $package_id = $_GET['package_id'];
            $channel_file = $data_folder . '/channel/channel_' . $package_id . '.txt';
            $data = get_txt_data($channel_file, $config);
        } else {
            $data = ['error' => 'package_id is required'];
        }
        break;
        
    case 'links':
        if (isset($_GET['channel_id'])) {
            $channel_id = $_GET['channel_id'];
            $link_file = $data_folder . '/link/link_' . $channel_id . '.txt';
            $data = get_txt_data($link_file, $config);
        } else {
            $data = ['error' => 'channel_id is required'];
        }
        break;
        
    default:
        $data = ['error' => 'Invalid type specified'];
        break;
}

// لا حاجة لـ array_values هنا لأنها تمت في get_txt_data
echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
?>
