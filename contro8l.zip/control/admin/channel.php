<?php
session_start();
$config = require __DIR__ . '/../config.php';
if(!isset($_SESSION['admin_logged'])) exit('غير مصرح');

// ===== دوال التشفير المعدلة (بدون IV، طريقة غير آمنة) =====

// دالة التشفير
function encrypt_data($data, $config) {
    $key = hash('sha256', $config['encryption_key'], true);
    $encrypted = openssl_encrypt($data, 'AES-256-ECB', $key, OPENSSL_RAW_DATA);
    return base64_encode($encrypted);
}

// دالة فك التشفير
function decrypt_data($data, $config) {
    $encrypted_data = base64_decode($data);
    $key = hash('sha256', $config['encryption_key'], true);
    $decrypted = openssl_decrypt($encrypted_data, 'AES-256-ECB', $key, OPENSSL_RAW_DATA);
    return $decrypted ?: '';
}

// ==========================================================

function get_txt_data($file, $config){
    if(!file_exists($file)) return [];
    $encrypted_data = file_get_contents($file);
    $decrypted_data = decrypt_data($encrypted_data, $config);
    return json_decode($decrypted_data, true) ?: [];
}

$package_id = $_GET['package_id'] ?? exit('مطلوب package_id');
$data_folder = $config['data_folder'];
$channel_file = $data_folder.'/channel/channel_'.$package_id.'.txt';
$channels = get_txt_data($channel_file, $config);
?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <title>قنوات الباقة</title>
    <style>
        * { margin:0; padding:0; box-sizing:border-box; font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        body { background: linear-gradient(135deg,#0f2027,#203a43,#2c5364); min-height:100vh; padding:30px 15px; color:#fff; }
        .container { max-width:900px; margin:0 auto; }
        h2,h3 { text-align:center; font-size:32px; margin-bottom:25px; text-shadow:2px 2px 10px rgba(0,0,0,0.5); }
        a.back { display:inline-block; background:linear-gradient(45deg,#6a11cb,#2575fc); padding:10px 20px; border-radius:12px; text-decoration:none; color:#fff; font-weight:bold; transition:0.3s; margin-bottom:20px; }
        a.back:hover { transform:translateY(-2px); box-shadow:0 6px 20px rgba(0,0,0,0.3); }
        form.add-channel { background: rgba(255,255,255,0.08); padding:25px; border-radius:20px; box-shadow:0 10px 35px rgba(0,0,0,0.5); margin-bottom:40px; display:flex; flex-wrap:wrap; gap:15px; justify-content:center; }
        form.add-channel input[type="text"] { padding:12px 15px; border:none; border-radius:12px; flex:1 1 200px; font-size:16px; background: rgba(255,255,255,0.15); color:#fff; }
        form.add-channel input::placeholder { color: rgba(255,255,255,0.7); }
        form.add-channel button { padding:12px 25px; border:none; border-radius:12px; background:linear-gradient(45deg,#ff416c,#ff4b2b); font-weight:bold; cursor:pointer; transition:0.3s; color:#fff; }
        form.add-channel button:hover { transform:translateY(-2px); box-shadow:0 6px 20px rgba(0,0,0,0.3); }
        ul.channels { list-style:none; display:grid; grid-template-columns:repeat(auto-fit,minmax(280px,1fr)); gap:20px; padding:0; }
        li.channel { background: rgba(255,255,255,0.08); padding:20px; border-radius:20px; box-shadow:0 10px 35px rgba(0,0,0,0.5); display:flex; flex-direction:column; align-items:center; text-align:center; transition:0.3s; position:relative; }
        li.channel:hover { transform:translateY(-5px); box-shadow:0 15px 40px rgba(0,0,0,0.6); }
        li.channel img { width:100px; height:100px; border-radius:15px; object-fit:cover; margin-bottom:15px; border:3px solid #fff; }
        li.channel strong { font-size:20px; margin-bottom:15px; display:block; }
        .actions { display:flex; gap:10px; flex-wrap:wrap; justify-content:center; margin-bottom:10px; }
        .actions button, .actions a { padding:10px 15px; border:none; border-radius:12px; font-weight:bold; cursor:pointer; text-decoration:none; color:#fff; transition:0.3s; font-size:14px; }
        .actions button.delete { background: linear-gradient(135deg,#ff416c,#ff4b2b); }
        .actions button.edit { background: linear-gradient(135deg,#00c6ff,#0072ff); }
        .actions a.server { background: linear-gradient(135deg,#43cea2,#185a9d); }
        .actions button:hover, .actions a:hover { transform:translateY(-2px); box-shadow:0 10px 20px rgba(0,0,0,0.5); }
        .edit-form { display:none; flex-direction:column; gap:10px; width:100%; background: rgba(255,255,255,0.05); padding:10px; border-radius:12px; margin-top:10px; }
        .edit-form input[type="text"] { padding:10px; border-radius:12px; border:none; background: rgba(255,255,255,0.15); color:#fff; }
        .edit-form button { padding:10px; border-radius:12px; border:none; background:linear-gradient(135deg,#00c6ff,#0072ff); color:#fff; font-weight:bold; cursor:pointer; transition:0.3s; }
    </style>
    <script>
        function toggleEdit(id){
            var f = document.getElementById('edit-form-'+id);
            f.style.display = (f.style.display === 'none' || f.style.display === '') ? 'flex' : 'none';
        }
    </script>
</head>
<body>
    <div class="container">
        <h2>قنوات الباقة</h2>
        <a class="back" href="index.php">رجوع للباقات</a>
        
        <h3>إضافة قناة جديدة</h3>
        <form class="add-channel" method="post" action="save.php">
            <input type="hidden" name="type" value="add_channel">
            <input type="hidden" name="package_id" value="<?php echo $package_id; ?>">
            <input type="text" name="name" placeholder="اسم القناة" required>
            <input type="text" name="img" placeholder="رابط الصورة">
            <button type="submit">إضافة قناة</button>
        </form>
        
        <h3>القنوات الحالية</h3>
        <ul class="channels">
            <?php foreach($channels as $ch): ?>
            <li class="channel">
                <?php if(!empty($ch['img'])): ?><img src="<?php echo htmlspecialchars($ch['img']); ?>"><?php endif; ?>
                <strong><?php echo htmlspecialchars($ch['name']); ?></strong>
                <div class="actions">
                    <form method="post" action="save.php" style="display:inline;" onsubmit="return confirm('هل أنت متأكد من حذف هذه القناة؟');">
                        <input type="hidden" name="type" value="delete_channel">
                        <input type="hidden" name="id" value="<?php echo $ch['id']; ?>">
                        <input type="hidden" name="package_id" value="<?php echo $package_id; ?>">
                        <button type="submit" class="delete">حذف</button>
                    </form>
                    <a class="server" href="link.php?channel_id=<?php echo $ch['id']; ?>">سيرفرات القناة</a>
                    <button type="button" class="edit" onclick="toggleEdit('<?php echo $ch['id']; ?>')">تعديل</button>
                </div>
                <form method="post" action="save.php" class="edit-form" id="edit-form-<?php echo $ch['id']; ?>">
                    <input type="hidden" name="type" value="edit_channel">
                    <input type="hidden" name="id" value="<?php echo $ch['id']; ?>">
                    <input type="hidden" name="package_id" value="<?php echo $package_id; ?>">
                    <input type="text" name="name" value="<?php echo htmlspecialchars($ch['name']); ?>" placeholder="اسم القناة">
                    <input type="text" name="img" value="<?php echo htmlspecialchars($ch['img']); ?>" placeholder="رابط الصورة">
                    <button type="submit">حفظ التعديلات</button>
                </form>
            </li>
            <?php endforeach; ?>
        </ul>
    </div>
</body>
</html>
