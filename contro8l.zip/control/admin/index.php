<?php
session_start();
$config = require __DIR__ . '/../config.php';

// ===== دوال التشفير المعدلة (بدون IV، طريقة غير آمنة) =====

// دالة التشفير
function encrypt_data($data, $config) {
    $key = hash('sha256', $config['encryption_key'], true);
    $encrypted = openssl_encrypt($data, 'AES-256-ECB', $key, OPENSSL_RAW_DATA);
    return base64_encode($encrypted);
}

// دالة فك التشفير
function decrypt_data($data, $config) {
    $encrypted_data = base64_decode($data);
    $key = hash('sha256', $config['encryption_key'], true);
    $decrypted = openssl_decrypt($encrypted_data, 'AES-256-ECB', $key, OPENSSL_RAW_DATA);
    return $decrypted ?: '';
}

// ==========================================================

if (isset($_POST['pass'])) {
    if ($_POST['pass'] === $config['admin_pass']) {
        $_SESSION['admin_logged'] = true;
    } else {
        $error = "كلمة المرور خاطئة";
    }
}

if (!isset($_SESSION['admin_logged'])):
?>
<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <title>Admin Login</title>
    <style>
        * {margin:0;padding:0;box-sizing:border-box;font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;}
        body {background: linear-gradient(135deg,#0f2027,#203a43,#2c5364); min-height:100vh; display:flex; justify-content:center; align-items:center; padding:20px; color:#fff;}
        h2 {text-align:center; margin-bottom:30px; font-size:32px; font-weight:bold; letter-spacing:1px; text-shadow:2px 2px 8px rgba(0,0,0,0.5);}
        form {background-color: rgba(255,255,255,0.08); padding:30px 35px; border-radius:20px; box-shadow:0 15px 40px rgba(0,0,0,0.5); width:100%; max-width:400px; display:flex; flex-direction:column; gap:15px;}
        input[type="password"] {width:100%; padding:14px 18px; border:none; border-radius:12px; font-size:16px; background: rgba(255,255,255,0.15); color:#fff;}
        input::placeholder {color: rgba(255,255,255,0.7);}
        button {padding:14px; border:none; border-radius:12px; font-size:16px; font-weight:bold; cursor:pointer; background: linear-gradient(135deg,#ff416c,#ff4b2b); color:#fff; transition:0.3s; box-shadow:0 5px 15px rgba(0,0,0,0.3);}
        button:hover {transform: translateY(-2px); box-shadow:0 10px 20px rgba(0,0,0,0.4);}
        p[style*="color:red"] {background: rgba(255,0,0,0.2); padding:10px; border-radius:10px; text-align:center; font-weight:bold;}
    </style>
</head>
<body>
    <form method="post">
        <h2>تسجيل دخول الأدمن</h2>
        <input type="password" name="pass" placeholder="كلمة المرور" required>
        <button type="submit">دخول</button>
        <?php if(isset($error)) echo "<p style='color:red;'>$error</p>"; ?>
    </form>
</body>
</html>
<?php exit; endif; ?>

<?php
if(isset($_GET['logout'])) {
    session_destroy();
    header("Location: index.php");
    exit;
}

function get_txt_data($file, $config){
    if(!file_exists($file)) return [];
    $encrypted_data = file_get_contents($file);
    $decrypted_data = decrypt_data($encrypted_data, $config);
    return json_decode($decrypted_data, true) ?: [];
}

$data_folder = $config['data_folder'];
$packages_file = $data_folder.'/packages.txt';
$packages = get_txt_data($packages_file, $config);
?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <title>لوحة الأدمن</title>
    <style>
        * {margin:0;padding:0;box-sizing:border-box;font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;}
        body {background: linear-gradient(135deg,#0f2027,#203a43,#2c5364); min-height:100vh; display:flex; flex-direction:column; align-items:center; padding:20px; color:#fff;}
        h2 {text-align:center; margin-bottom:25px; font-size:28px; font-weight:bold; text-shadow:2px 2px 10px rgba(0,0,0,0.5);}
        a.logout {position:fixed; top:20px; right:20px; background:#ff416c; padding:10px 15px; border-radius:12px; font-weight:bold; text-decoration:none; color:#fff; box-shadow:0 5px 15px rgba(0,0,0,0.3); transition:0.3s;}
        a.logout:hover {transform:translateY(-2px); box-shadow:0 10px 20px rgba(0,0,0,0.4);}
        .add-form {background: rgba(255,255,255,0.08); padding:25px; border-radius:20px; box-shadow:0 10px 35px rgba(0,0,0,0.5); max-width:500px; width:100%; display:flex; flex-direction:column; gap:12px; margin-bottom:40px;}
        .add-form input[type="text"] {padding:12px 15px; border:none; border-radius:12px; font-size:16px; background: rgba(255,255,255,0.15); color:#fff;}
        .add-form input::placeholder {color: rgba(255,255,255,0.7);}
        .add-form button {padding:12px; border:none; border-radius:12px; background: linear-gradient(135deg,#ff416c,#ff4b2b); font-weight:bold; color:#fff; font-size:16px; cursor:pointer; transition:0.3s; box-shadow:0 5px 15px rgba(0,0,0,0.3);}
        .add-form button:hover {transform:translateY(-2px); box-shadow:0 10px 20px rgba(0,0,0,0.4);}
        .packages {display:flex; flex-wrap:wrap; gap:20px; justify-content:center; width:100%; max-width:1000px;}
        .package-card {background: rgba(255,255,255,0.08); border-radius:20px; padding:20px; width:280px; display:flex; flex-direction:column; align-items:center; box-shadow:0 10px 35px rgba(0,0,0,0.5); transition:0.3s; position:relative;}
        .package-card:hover {transform:translateY(-5px); box-shadow:0 15px 40px rgba(0,0,0,0.6);}
        .package-card img {width:120px; height:120px; border-radius:15px; object-fit:cover; margin-bottom:15px; border:3px solid #fff;}
        .package-card h4 {font-size:20px; margin-bottom:10px; text-align:center;}
        .package-actions {display:flex; gap:10px; flex-wrap:wrap; justify-content:center; margin-bottom:10px;}
        .package-actions button, .package-actions a {padding:8px 12px; border:none; border-radius:12px; font-weight:bold; cursor:pointer; transition:0.3s; text-decoration:none; color:#fff; font-size:14px; box-shadow:0 5px 15px rgba(0,0,0,0.3);}
        .package-actions button.edit {background: linear-gradient(135deg,#00c6ff,#0072ff);}
        .package-actions button.delete {background: linear-gradient(135deg,#ff416c,#ff4b2b);}
        .package-actions a.view {background: linear-gradient(135deg,#f7971e,#ffd200);}
        .package-actions button:hover, .package-actions a:hover {transform:translateY(-2px); box-shadow:0 10px 20px rgba(0,0,0,0.5);}
        .edit-form {display:none; flex-direction:column; gap:10px; width:100%; background: rgba(255,255,255,0.05); padding:10px; border-radius:12px;}
        .edit-form input[type="text"] {padding:10px; border-radius:10px; border:none; background: rgba(255,255,255,0.15); color:#fff;}
        .edit-form button {padding:10px; border-radius:12px; border:none; background:linear-gradient(135deg,#00c6ff,#0072ff); color:#fff; font-weight:bold; cursor:pointer; transition:0.3s;}
        .edit-form button:hover {transform:translateY(-2px); box-shadow:0 10px 20px rgba(0,0,0,0.5);}
    </style>
    <script>
        function toggleEdit(id){
            var f = document.getElementById('edit-form-'+id);
            f.style.display = (f.style.display === 'none' || f.style.display === '') ? 'flex' : 'none';
        }
    </script>
</head>
<body>
    <a class="logout" href="?logout=1">تسجيل خروج</a>
    <h2>لوحة إدارة الباقات</h2>
    
    <form class="add-form" method="post" action="save.php">
        <input type="hidden" name="type" value="add_package">
        <input type="text" name="name" placeholder="اسم الباقة" required>
        <input type="text" name="img" placeholder="رابط الصورة">
        <button type="submit">إضافة باقة جديدة</button>
    </form>
    
    <div class="packages">
        <?php foreach($packages as $pkg): ?>
        <div class="package-card">
            <?php if(!empty($pkg['img'])): ?><img src="<?php echo htmlspecialchars($pkg['img']); ?>"><?php endif; ?>
            <h4><?php echo htmlspecialchars($pkg['name']); ?></h4>
            <div class="package-actions">
                <form method="post" action="save.php" style="display:inline;" onsubmit="return confirm('هل أنت متأكد من حذف هذه الباقة وكل ما يتعلق بها؟');">
                    <input type="hidden" name="type" value="delete_package">
                    <input type="hidden" name="id" value="<?php echo $pkg['id']; ?>">
                    <button type="submit" class="delete">حذف</button>
                </form>
                <a class="view" href="channel.php?package_id=<?php echo $pkg['id']; ?>">قنوات الباقة</a>
                <button type="button" class="edit" onclick="toggleEdit(<?php echo $pkg['id']; ?>)">تعديل</button>
            </div>
            <form method="post" action="save.php" class="edit-form" id="edit-form-<?php echo $pkg['id']; ?>">
                <input type="hidden" name="type" value="edit_package">
                <input type="hidden" name="id" value="<?php echo $pkg['id']; ?>">
                <input type="text" name="name" value="<?php echo htmlspecialchars($pkg['name']); ?>" placeholder="اسم الباقة">
                <input type="text" name="img" value="<?php echo htmlspecialchars($pkg['img']); ?>" placeholder="رابط الصورة">
                <button type="submit">حفظ التعديلات</button>
            </form>
        </div>
        <?php endforeach; ?>
    </div>
</body>
</html>
