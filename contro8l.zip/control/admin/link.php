<?php
session_start();
$config = require __DIR__ . '/../config.php';
if(!isset($_SESSION['admin_logged'])) exit('غير مصرح');

// ===== دوال التشفير المعدلة (بدون IV، طريقة غير آمنة) =====

// دالة التشفير
function encrypt_data($data, $config) {
    $key = hash('sha256', $config['encryption_key'], true);
    $encrypted = openssl_encrypt($data, 'AES-256-ECB', $key, OPENSSL_RAW_DATA);
    return base64_encode($encrypted);
}

// دالة فك التشفير
function decrypt_data($data, $config) {
    $encrypted_data = base64_decode($data);
    $key = hash('sha256', $config['encryption_key'], true);
    $decrypted = openssl_decrypt($encrypted_data, 'AES-256-ECB', $key, OPENSSL_RAW_DATA);
    return $decrypted ?: '';
}

// ==========================================================

function get_txt_data($file, $config){
    if(!file_exists($file)) return [];
    $encrypted_data = file_get_contents($file);
    $decrypted_data = decrypt_data($encrypted_data, $config);
    return json_decode($decrypted_data, true) ?: [];
}

$channel_id = $_GET['channel_id'] ?? exit('مطلوب channel_id');
$data_folder = $config['data_folder'];
$link_file = $data_folder.'/link/link_'.$channel_id.'.txt';
$links = get_txt_data($link_file, $config);
?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <title>سيرفرات القناة</title>
    <style>
        * { margin:0; padding:0; box-sizing:border-box; font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        body { background: linear-gradient(135deg,#0f2027,#203a43,#2c5364); min-height:100vh; padding:30px 15px; color:#fff; }
        .container { max-width:1000px; margin:0 auto; }
        h2,h3 { text-align:center; font-size:32px; margin-bottom:25px; text-shadow:2px 2px 10px rgba(0,0,0,0.5); }
        a.back { display:inline-block; background:linear-gradient(45deg,#6a11cb,#2575fc); padding:10px 20px; border-radius:12px; text-decoration:none; color:#fff; font-weight:bold; transition:0.3s; margin-bottom:20px; }
        a.back:hover { transform:translateY(-2px); box-shadow:0 6px 20px rgba(0,0,0,0.3); }
        form.add-link { background: rgba(255,255,255,0.08); padding:25px; border-radius:20px; box-shadow:0 10px 35px rgba(0,0,0,0.5); margin-bottom:40px; display:flex; flex-wrap:wrap; gap:15px; justify-content:center; }
        form.add-link input[type="text"] { padding:12px 15px; border:none; border-radius:12px; flex:1 1 200px; font-size:16px; background: rgba(255,255,255,0.15); color:#fff; }
        form.add-link input::placeholder { color: rgba(255,255,255,0.7); }
        form.add-link button { padding:12px 25px; border:none; border-radius:12px; background:linear-gradient(45deg,#ff416c,#ff4b2b); font-weight:bold; cursor:pointer; transition:0.3s; color:#fff; }
        ul.links { list-style:none; display:grid; grid-template-columns:repeat(auto-fit,minmax(300px,1fr)); gap:20px; padding:0; }
        li.link { background: rgba(255,255,255,0.08); padding:20px; border-radius:20px; box-shadow:0 10px 35px rgba(0,0,0,0.5); display:flex; flex-direction:column; align-items:center; text-align:center; transition:0.3s; }
        li.link strong { font-size:20px; margin-bottom:10px; display:block; }
        li.link ul { list-style:none; padding:0; margin-bottom:15px; text-align:right; width:100%;}
        li.link li { word-break:break-all; margin-bottom:5px; }
        .actions { display:flex; gap:10px; flex-wrap:wrap; justify-content:center; }
        .actions button { padding:10px 15px; border:none; border-radius:12px; font-weight:bold; cursor:pointer; color:#fff; transition:0.3s; font-size:14px; }
        .actions button.delete { background: linear-gradient(135deg,#ff416c,#ff4b2b); }
        .actions button.edit { background: linear-gradient(135deg,#00c6ff,#0072ff); }
        .edit-form { display:none; flex-direction:column; gap:10px; width:100%; background: rgba(255,255,255,0.05); padding:15px; border-radius:12px; margin-top:15px; }
        .edit-form input[type="text"] { padding:10px; border-radius:12px; border:none; background: rgba(255,255,255,0.15); color:#fff; width:100%; }
        .edit-form button { padding:10px; border-radius:12px; border:none; background:linear-gradient(135deg,#00c6ff,#0072ff); color:#fff; font-weight:bold; cursor:pointer; }
    </style>
    <script>
        function toggleEdit(id){
            var f = document.getElementById('edit-form-'+id);
            f.style.display = (f.style.display === 'none' || f.style.display === '') ? 'flex' : 'none';
        }
    </script>
</head>
<body>
    <div class="container">
        <h2>سيرفرات القناة</h2>
        <a class="back" onclick="history.back()">رجوع للقنوات</a>
        
        <h3>إضافة سيرفر جديد</h3>
        <form class="add-link" method="post" action="save.php">
            <input type="hidden" name="type" value="add_link">
            <input type="hidden" name="channel_id" value="<?php echo $channel_id; ?>">
            <input type="text" name="name" placeholder="اسم السيرفر" required>
            <input type="text" name="url" placeholder="Url">
            <input type="text" name="useragent" placeholder="UserAgent">
            <input type="text" name="origin" placeholder="Origin">
            <input type="text" name="referer" placeholder="Referer">
            <input type="text" name="drmkey" placeholder="Drmkey">
            <input type="text" name="cookie" placeholder="Cookie">
            <button type="submit">إضافة سيرفر</button>
        </form>
        
        <h3>السيرفرات الحالية</h3>
        <ul class="links">
            <?php foreach($links as $l): ?>
            <li class="link">
                <strong><?php echo htmlspecialchars($l['name'] ?: 'N/A'); ?></strong>
                <ul>
                    <li><strong>Url:</strong> <?php echo htmlspecialchars($l['url'] ?: 'N/A'); ?></li>
                    <li><strong>UserAgent:</strong> <?php echo htmlspecialchars($l['useragent'] ?: 'N/A'); ?></li>
                    <li><strong>Origin:</strong> <?php echo htmlspecialchars($l['origin'] ?: 'N/A'); ?></li>
                    <li><strong>Referer:</strong> <?php echo htmlspecialchars($l['referer'] ?: 'N/A'); ?></li>
                    <li><strong>Drmkey:</strong> <?php echo htmlspecialchars($l['drmkey'] ?: 'N/A'); ?></li>
                    <li><strong>Cookie:</strong> <?php echo htmlspecialchars($l['cookie'] ?: 'N/A'); ?></li>
                </ul>
                <div class="actions">
                    <form method="post" action="save.php" style="display:inline;" onsubmit="return confirm('هل أنت متأكد من حذف هذا السيرفر؟');">
                        <input type="hidden" name="type" value="delete_link">
                        <input type="hidden" name="id" value="<?php echo $l['id']; ?>">
                        <input type="hidden" name="channel_id" value="<?php echo $channel_id; ?>">
                        <button type="submit" class="delete">حذف</button>
                    </form>
                    <button type="button" class="edit" onclick="toggleEdit('<?php echo $l['id']; ?>')">تعديل</button>
                </div>
                <form method="post" action="save.php" class="edit-form" id="edit-form-<?php echo $l['id']; ?>">
                    <input type="hidden" name="type" value="edit_link">
                    <input type="hidden" name="id" value="<?php echo $l['id']; ?>">
                    <input type="hidden" name="channel_id" value="<?php echo $channel_id; ?>">
                    <input type="text" name="name" value="<?php echo htmlspecialchars($l['name'] ?? ''); ?>" placeholder="اسم السيرفر">
                    <input type="text" name="url" value="<?php echo htmlspecialchars($l['url'] ?? ''); ?>" placeholder="Url">
                    <input type="text" name="useragent" value="<?php echo htmlspecialchars($l['useragent'] ?? ''); ?>" placeholder="UserAgent">
                    <input type="text" name="origin" value="<?php echo htmlspecialchars($l['origin'] ?? ''); ?>" placeholder="Origin">
                    <input type="text" name="referer" value="<?php echo htmlspecialchars($l['referer'] ?? ''); ?>" placeholder="Referer">
                    <input type="text" name="drmkey" value="<?php echo htmlspecialchars($l['drmkey'] ?? ''); ?>" placeholder="Drmkey">
                    <input type="text" name="cookie" value="<?php echo htmlspecialchars($l['cookie'] ?? ''); ?>" placeholder="Cookie">
                    <button type="submit">حفظ التعديلات</button>
                </form>
            </li>
            <?php endforeach; ?>
        </ul>
    </div>
</body>
</html>
