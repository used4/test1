<?php
session_start();
$config = require __DIR__ . '/../config.php';
if(!isset($_SESSION['admin_logged'])) exit('غير مصرح');

// ===== دوال التشفير (بدون IV، طريقة غير آمنة) =====

// دالة التشفير
function encrypt_data($data, $config) {
    $key = hash('sha256', $config['encryption_key'], true);
    $encrypted = openssl_encrypt($data, 'AES-256-ECB', $key, OPENSSL_RAW_DATA);
    return base64_encode($encrypted);
}

// دالة فك التشفير
function decrypt_data($data, $config) {
    $encrypted_data = base64_decode($data);
    $key = hash('sha256', $config['encryption_key'], true);
    $decrypted = openssl_decrypt($encrypted_data, 'AES-256-ECB', $key, OPENSSL_RAW_DATA);
    return $decrypted ?: '';
}

// ==========================================================

$data_folder = $config['data_folder'];
$channel_folder = $data_folder.'/channel';
$link_folder = $data_folder.'/link';

// إنشاء المجلدات إذا لم تكن موجودة
if(!file_exists($data_folder)) mkdir($data_folder, 0777, true);
if(!file_exists($channel_folder)) mkdir($channel_folder, 0777, true);
if(!file_exists($link_folder)) mkdir($link_folder, 0777, true);

// دالات التعامل مع ملفات txt مع التشفير
function get_txt_data($file, $config){
    if(!file_exists($file)) return [];
    $encrypted_data = file_get_contents($file);
    $decrypted_data = decrypt_data($encrypted_data, $config);
    return json_decode($decrypted_data, true) ?: [];
}

function save_txt_data($file, $data, $config){
    $json_data = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    $encrypted_data = encrypt_data($json_data, $config);
    file_put_contents($file, $encrypted_data);
}

$type = $_POST['type'] ?? '';

# إضافة باقة
if($type=='add_package'){
    $packages_file = $data_folder.'/packages.txt';
    $packages = get_txt_data($packages_file, $config);
    $id = time();
    $packages[] = ['id'=>$id, 'name'=>$_POST['name'] ?? '', 'img'=>$_POST['img'] ?? ''];
    save_txt_data($packages_file, $packages, $config);
    
    $channel_file = $channel_folder.'/channel_'.$id.'.txt';
    save_txt_data($channel_file, [], $config);
    header('Location: index.php');
}

# تعديل باقة
if($type=='edit_package'){
    $packages_file = $data_folder.'/packages.txt';
    $packages = get_txt_data($packages_file, $config);
    foreach($packages as &$p){
        if($p['id'] == $_POST['id']){
            $p['name'] = $_POST['name'] ?? '';
            $p['img'] = $_POST['img'] ?? '';
            break;
        }
    }
    save_txt_data($packages_file, $packages, $config);
    header('Location: index.php');
}

# حذف باقة
if($type=='delete_package'){
    $packages_file = $data_folder.'/packages.txt';
    $packages = get_txt_data($packages_file, $config);
    $package_id = $_POST['id'];
    
    $channel_file = $channel_folder.'/channel_'.$package_id.'.txt';
    if(file_exists($channel_file)){
        $channels = get_txt_data($channel_file, $config);
        foreach($channels as $c){
            $link_file = $link_folder.'/link_'.$c['id'].'.txt';
            if(file_exists($link_file)) unlink($link_file);
        }
        unlink($channel_file);
    }
    
    $packages = array_filter($packages, function($p) use($package_id){
        return $p['id'] != $package_id;
    });
    
    // *** الإصلاح هنا: إعادة ترتيب مفاتيح المصفوفة ***
    $packages = array_values($packages);
    
    save_txt_data($packages_file, $packages, $config);
    header('Location: index.php');
}

# إضافة قناة
if($type=='add_channel'){
    $package_id = $_POST['package_id'];
    $channel_file = $channel_folder.'/channel_'.$package_id.'.txt';
    $channels = get_txt_data($channel_file, $config);
    $id = time();
    $channels[] = ['id'=>$id, 'name'=>$_POST['name'] ?? '', 'img'=>$_POST['img'] ?? ''];
    save_txt_data($channel_file, $channels, $config);
    
    $link_file = $link_folder.'/link_'.$id.'.txt';
    save_txt_data($link_file, [], $config);
    header('Location: channel.php?package_id='.$package_id);
}

# تعديل قناة
if($type=='edit_channel'){
    $package_id = $_POST['package_id'];
    $channel_file = $channel_folder.'/channel_'.$package_id.'.txt';
    $channels = get_txt_data($channel_file, $config);
    foreach($channels as &$c){
        if($c['id'] == $_POST['id']){
            $c['name'] = $_POST['name'] ?? '';
            $c['img'] = $_POST['img'] ?? '';
            break;
        }
    }
    save_txt_data($channel_file, $channels, $config);
    header('Location: channel.php?package_id='.$package_id);
}

# حذف قناة
if($type=='delete_channel'){
    $package_id = $_POST['package_id'];
    $channel_file = $channel_folder.'/channel_'.$package_id.'.txt';
    $channels = get_txt_data($channel_file, $config);
    $channel_id = $_POST['id'];
    
    $link_file = $link_folder.'/link_'.$channel_id.'.txt';
    if(file_exists($link_file)) unlink($link_file);
    
    $channels = array_filter($channels, function($c) use($channel_id){
        return $c['id'] != $channel_id;
    });

    // *** الإصلاح هنا: إعادة ترتيب مفاتيح المصفوفة ***
    $channels = array_values($channels);

    save_txt_data($channel_file, $channels, $config);
    header('Location: channel.php?package_id='.$package_id);
}

# إضافة سيرفر
if($type=='add_link'){
    $channel_id = $_POST['channel_id'];
    $link_file = $link_folder.'/link_'.$channel_id.'.txt';
    $links = get_txt_data($link_file, $config);
    $id = time();
    $links[] = [
        'id'=>$id, 'name'=>$_POST['name'] ?? '', 'url'=>$_POST['url'] ?? '',
        'useragent'=>$_POST['useragent'] ?? '', 'origin'=>$_POST['origin'] ?? '',
        'referer'=>$_POST['referer'] ?? '', 'drmkey'=>$_POST['drmkey'] ?? '',
        'cookie'=>$_POST['cookie'] ?? ''
    ];
    save_txt_data($link_file, $links, $config);
    header('Location: link.php?channel_id='.$channel_id);
}

# تعديل سيرفر
if($type=='edit_link'){
    $channel_id = $_POST['channel_id'];
    $link_file = $link_folder.'/link_'.$channel_id.'.txt';
    $links = get_txt_data($link_file, $config);
    foreach($links as &$l){
        if($l['id'] == $_POST['id']){
            $l['name'] = $_POST['name'] ?? ''; $l['url'] = $_POST['url'] ?? '';
            $l['useragent'] = $_POST['useragent'] ?? ''; $l['origin'] = $_POST['origin'] ?? '';
            $l['referer'] = $_POST['referer'] ?? ''; $l['drmkey'] = $_POST['drmkey'] ?? '';
            $l['cookie'] = $_POST['cookie'] ?? '';
            break;
        }
    }
    save_txt_data($link_file, $links, $config);
    header('Location: link.php?channel_id='.$channel_id);
}

# حذف سيرفر
if($type=='delete_link'){
    $channel_id = $_POST['channel_id'];
    $link_file = $link_folder.'/link_'.$channel_id.'.txt';
    $links = get_txt_data($link_file, $config);
    $link_id = $_POST['id'];
    
    $links = array_filter($links, function($l) use($link_id){
        return $l['id'] != $link_id;
    });
    
    // *** الإصلاح هنا: إعادة ترتيب مفاتيح المصفوفة ***
    $links = array_values($links);
    
    if(empty($links)){
        if(file_exists($link_file)) unlink($link_file);
    } else {
        save_txt_data($link_file, $links, $config);
    }
    header('Location: link.php?channel_id='.$channel_id);
}
?>
