<?php
return [
    'admin_pass' => '4362',
    'data_folder' => __DIR__ . '/api/listtv',
    'encryption_key' => 'AmeerMatchNow$@&zz2024SecureKey!!'
];
?>