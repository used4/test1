<?php 
include ('includes/header.php');

//table name
$table_name = "actreq";
$page_my = "activation_request.php";
$pagemac = "user_manage.php";

//table call
$res = $db->select($table_name, '*', '', '');

//delete row
if(isset($_GET['delete'])){
	$db->delete($table_name, 'id = :id',[':id' => $_GET['delete']]);
	echo "<script>window.location.href='".$page_my."?status=ok'</script>";
}

if (isset($_GET['confirm_wipe']) && $_GET['confirm_wipe'] == 1) {
    $db->deleteAll($table_name);
    echo "<script>window.location.href='".$page_my."?status=ok'</script>";
    exit;
}


?>

<script>
function confirmDelete() {
    if (confirm("⚠️ All data will be deleted!\nAre you sure?")) {
        window.location.href = "<?= $page_my ?>?confirm_wipe=1";
    } else {
        alert("❌ Deletion has been cancelled.");
    }
}

</script>
<div class="container-fluid pt-4 px-4">
    <div class="row g-4">
        <div class="col-12">
            <div class="bg-secondary rounded h-100 p-4">
                <h2 class="mb-4">Current Activation requests</h6>
                    <div class="text-end">
                        <a type="button" href="#" onclick="confirmDelete()" class="btn btn-square btn-primary m-2"><i
                                class="fa fa-eraser"></i></a>
                    </div>

                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Mac Address</th>
                                    <th>Date of request</th>
                                    <th>Remark</th>
                                    <th>Add Playlist</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                            <?php foreach ($res as $row) {
							?>
                            <tbody>
                                <tr>
                                    <td><?=$row['id']; ?></a></td>
                                    <td><?=$row['mac'] ?></a></td>
                                    <td><?=$row['date'] ?></a></td>
                                    <td><?=$row['remark'] ?></td>
                                    <td><a class="btn btn-square btn-warning m-2"
                                            href="<?php echo $pagemac; ?>?create&mac=<?php echo $row['mac']; ?>">
                                            <i class="fa fa-users"></i>
                                        </a></td>
                                    <td><a class="btn btn-square btn-primary m-2" href="#"
                                            data-href="<?php echo $page_my; ?>?delete=<?php echo $row['id']; ?>"
                                            data-bs-toggle="modal" data-bs-target="#confirm-delete">
                                            <i class="fa fa-trash"></i>
                                        </a></td>
                                </tr>
                            </tbody>
                            <?php
							}?>
                        </table>
                    </div>
            </div>
        </div>
    </div>
</div>
<!-- Table End -->

<?php ?>
<!-- Footer Start -->
<?php include ('includes/footer.php');?>
<!-- Footer End -->
</body>

</html>