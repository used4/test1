<?php

$dbPath = './api/.db.db';
$db = new SQLiteWrapper($dbPath);
$dbkm = new SQLiteWrapper($dbPath);
?>