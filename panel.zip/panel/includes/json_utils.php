<?php

function updateJsonRecordById($id, $newData) {
    $json = file_get_contents('./settings/superuser.json');
    $data = json_decode($json, true);

    foreach ($data as &$item) {
        if ($item['id'] == $id) {
            foreach ($newData as $key => $value) {
                if (array_key_exists($key, $item)) {
                    $item[$key] = $value;
                }
            }
            break;
        }
    }

    file_put_contents('./settings/superuser.json', json_encode($data, JSON_PRETTY_PRINT));
    return true;
}
function updateJsonRecordByIdMulty($id, $newData) {
    $json = file_get_contents('./settings/superuser.json');
    $data = json_decode($json, true);

    foreach ($data as &$item) {
        if ($item['id'] == $id) {
            foreach ($newData as $key => $value) {
                $item[$key] = $value;
            }
            break;
        }
    }

    file_put_contents('./settings/superuser.json', json_encode($data, JSON_PRETTY_PRINT));
}

function getJsonRecordById($id) {
    // Read the JSON file
    $json = file_get_contents('./settings/superuser.json');
    $data = json_decode($json, true);

    // Search for the record with the given ID
    foreach ($data as $item) {
        if ($item['id'] == $id) {
            return $item; // Return the matching record
        }
    }

    return null; // If not found
}

function getmodsbyid($id){
    $getrecord = getJsonRecordById($id);
    $getmods_value = $getrecord['mods'];
    
    return $getmods_value;
}