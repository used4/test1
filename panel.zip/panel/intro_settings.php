<!-- index.php -->
<?php 
include ('includes/header.php');

$table_name = 'int';
$page_name = 'intro_settings';
$data = ['intro' => 'enable'];

$db->insertIfEmpty($table_name, $data);

$res = $db->select($table_name, '*', '', '');

if(isset($_POST['submit'])){
    unset($_POST['submit']);
    $updateData = $_POST;
    $db->update($table_name, $updateData, 'id = :id',[':id' => 1]);
    echo "<script>window.location.href='". $page_name.".php'</script>";
}


?>
<!-- Form Start -->
<div class="container-fluid pt-4 px-4">
    <div class="row g-4">
        <div class="col-12">
            <div class="bg-secondary rounded h-100 p-4">
                <h2 class="mb-4">Intro settings</h6>
                    <form method="post">
                        <select class="form-select mb-3" id="intro" name="intro">
                            <option value="enable" <?=$res[0]['intro']=='enable'?'selected':'' ?>>Enable</option>
							<option value="disable" <?=$res[0]['intro']=='disable'?'selected':'' ?>>Disable</option>
                        </select>
                        <button type="submit" name="submit" class="btn btn-primary">Update Intro settings</button>
                    </form>
            </div>
        </div>
    </div>
</div>
<!-- Form End -->

<!-- Footer Start -->
<?php include ('includes/footer.php');?>
<!-- Footer End -->
</body>

</html>