<!-- index.php -->
<?php 
include ('includes/header.php');

$table_name = 'user';
$page = 'user.php';
$res = $db->select($table_name, '*', '', '');

if(isset($_POST['submit'])){
	unset($_POST['submit']);
	$updateData = $_POST;
	$db->update($table_name, $updateData, 'id = :id',[':id' => 1]);
	session_regenerate_id();
	$_SESSION['loggedin'] = true;
	$_SESSION['name'] = $_POST['username'];
	echo "<script>window.location.href='". $page_name."'</script>";
}

?>
        <!-- Form Start -->
            <div class="container-fluid pt-4 px-4">
                <div class="row g-4">
                    <div class="col-12">
                        <div class="bg-secondary rounded h-100 p-4">
                            <h2 class="mb-4">Update Credentials</h6>
                            <form  method="post">
                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">User name or Email address</label>
                                    <input type="text" name="username" class="form-control" value="<?=$res[0]['username'] ?>">
                                    <div id="emailHelp" class="form-text">We'll never share your email or username with anyone else.
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label  class="form-label">Password</label>
                                    <input type="text" name="password" class="form-control" value="<?=$res[0]['password'] ?>" id="exampleInputPassword1">
                                </div>
                                <button type="submit" name="submit" class="btn btn-primary">Update Credentials</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Form End -->

<!-- Footer Start -->
<?php include ('includes/footer.php');?>
<!-- Footer End -->
</body>
</html>